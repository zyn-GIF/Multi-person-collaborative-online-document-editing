﻿#include "showfile.h"
#include "ui_showfile.h"
#include"widget.h"
showfile::showfile(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::showfile)
{
    //setWindowTitle(QStringLiteral("文件内容"));
    ui->setupUi(this);
    // timer = new QTimer(this);
    // connect(timer,&QTimer::timeout,this,&showfile::slot_modifyfile);
}

showfile::~showfile()
{
    delete ui;
}

void showfile::slot_showcontent(FILECONTENT* pfc)//显示文件内容
{
    m_fc=pfc;
    strcpy(FileName,pfc->m_szFileName);
    userId = pfc->m_userId;
    ui->textEdit->setPlainText(pfc->content);
    //strcpy(f_text,pfc->content);
    f_text = QString::fromUtf8(pfc->content);
    //获取文件MD5值
    //strcpy(FileMD5,FileDigest(m_fc->m_FilePath));
    FileMD5=FileDigest(m_fc->m_FilePath);
    ui->textEdit->setReadOnly(true);
    show();


}

void showfile::slot_modifyfile()
{
    // Sleep(5000);
    QString text = ui->textEdit->toPlainText();//现文件内容
    ModifyFile_RQ mr;
    mr.u_id = userId;

    strcpy(mr.m_szFileName,FileName);
    int num=0;

    if(ui->textEdit->document()->isModified())//判断文件是否被修改
    {
    //如果有改动 发送改动内容给服务器
    diff_match_patch dmp;
    QList<Diff> diffs = dmp.diff_main(f_text,text);
    dmp.diff_cleanupSemantic(diffs);
    int pos=0;
    for (const Diff &diff : diffs) {
        FileMD5=FileDigest(m_fc->m_FilePath);
        switch (diff.operation) {
        case op_INSERT:
            qDebug() << "在位置" << pos << "插入了:" << diff.text;
            ++num;
            mr.modify[num-1].pos = pos;
            mr.modify[num-1].type = MyInsert;
            strcpy(mr.modify[num-1].content,diff.text.toStdString().c_str());
            mr.modify[num-1].len=strlen(mr.modify[num-1].content);
            mr.modify[num-1].timestamp=QDateTime::currentMSecsSinceEpoch();
            strcpy(mr.modify[num-1].strMD5,FileMD5.c_str());
            break;
        case op_DELETE:
            qDebug() << "从位置" << pos << "删除了:" << diff.text;
            // 删除操作不增加位置
            ++num;
            mr.modify[num-1].pos = pos;
            mr.modify[num-1].type = MyDelete;
            strcpy(mr.modify[num-1].content,diff.text.toStdString().c_str());
            mr.modify[num-1].len=sizeof(mr.modify[num-1].content);
            mr.modify[num-1].timestamp=QDateTime::currentMSecsSinceEpoch();
            strcpy(mr.modify[num-1].strMD5,FileMD5.c_str());
            break;
        case op_EQUAL:
            pos += diff.text.length(); // 跳过相同部分
            break;
            }
        }

    mr.num = num;

    f_text=ui->textEdit->toPlainText();
    if(0==mr.num){
        printf("no modify\n");
        //如果没有修改可以睡眠一段时间
        return;
    }
    m_pkernel->sendData((char*)&mr,sizeof(mr));
    }
    return;


}

void showfile::slot_showmodify(ModifyFile_RS* mrs)//将修改内容广播应用在所有正在编辑的客户端
{
    for(int i=0;i<mrs->num;i++)
    {
        if(mrs->modify[i].u_id!=userId)
        {//如果这个操作是别人的 把他应用到自己的文件中
            int pos=mrs->modify[i].pos;
            QString content=mrs->modify[i].content;
            int len=mrs->modify[i].len;
            // 在指定位置插入或删除文本（通过 QTextCursor)
            QTextCursor cursor = ui->textEdit->textCursor();

            if(mrs->modify[i].type==MyInsert){
                cursor.setPosition(pos);
                cursor.insertText(content);
            }
            else if(mrs->modify[i].type==MyDelete){
                QTextCursor cursor = ui->textEdit->textCursor();
                cursor.setPosition(pos);
                cursor.movePosition(QTextCursor::Right, QTextCursor::KeepAnchor, len); // 选中范围
                cursor.removeSelectedText();
            }
            //更新f_text 避免事件循环陷阱
            this->f_text=ui->textEdit->toPlainText();
        }
    }
}

void showfile::on_pushButton_clicked()//编辑
{
    //QString text = ui->textEdit->toPlainText();
    ui->textEdit->document()->setModified();//清空修改标志
    if(0!=strcmp(m_fc->m_FilePermission,"read")){//用户的权限大于只读
    ui->textEdit->setReadOnly(false);//解除只读的模式
    // Modify_User_RQ mu;//发送给服务器 将用户加入到表中  表中保存了 所有正在编辑文件的用户及用户信息
    // mu.u_id=userId;
    // strcpy(mu.m_szFileName,FileName);
    // strcpy(mu.m_FilePermission,m_fc->m_FilePermission);
    // m_pkernel->sendData((char*)&mu,sizeof(mu));
    }
    else{
        const char* Result="no permission";
        QMessageBox::information(this,"titel",Result);
        return;
    }
   // bool a=ui->textEdit->isReadOnly();
    //Sleep(10000);

    // QTimer* timer = new QTimer(this);
    // connect(timer,&QTimer::timeout,this,&showfile::slot_modifyfile);
    std::thread td(&showfile::timerthread,this);
    td.detach();

}
void showfile::timerthread(){
   // timer->start(2000);
    while(1)
   {
        Sleep(2000);
        slot_modifyfile();
    }
}

std::string showfile::FileDigest(QString filename) {

    QFile file(filename);

    file.open(QIODevice::ReadOnly);
    if (!file.isOpen())
        return "";

    MD5 md5;
    char buffer[1024];
    while (1)
    {
        qint64 length =  file.read(buffer, 1024);

        if (length > 0)
            md5.update(buffer, length);
        else
            break;
    }
    file.close();
    return md5.toString();
}
