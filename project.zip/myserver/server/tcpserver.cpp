#include "tcpserver.h"
#include"../kernel/tcpkernel.h"

std::vector<int> TCPServer::clients={0};
TCPServer::TCPServer()
{
    m_socklisten =0;
}

TCPServer::~TCPServer()
{

}



bool TCPServer::initNetWork(const char *szip, short nport)
{
    WORD wVersionRequested;
    WSADATA wsaData;
    int err;

    /* Use the MAKEWORD(lowbyte, highbyte) macro declared in Windef.h */
    wVersionRequested = MAKEWORD(2, 2);

    err = WSAStartup(wVersionRequested, &wsaData);
    if (err != 0) {
        /* Tell the user that we could not find a usable */
        /* Winsock DLL.                                  */
        printf("WSAStartup failed with error: %d\n", err);
        return false;
    }

    if (LOBYTE(wsaData.wVersion) != 2 || HIBYTE(wsaData.wVersion) != 2) {
        /* Tell the user that we could not find a usable */
        /* WinSock DLL.                                  */
        uninitNetWork("Could not find a usable version of Winsock.dll\n");
        return false;
    }
    else
        printf("The Winsock 2.2 dll was found okay\n");

    m_socklisten = socket(AF_INET,SOCK_STREAM,0);
    if(m_socklisten == INVALID_SOCKET){
        uninitNetWork("socket err\n");
        return false;
    }
    sockaddr_in  addrserver;
    addrserver.sin_family = AF_INET;
    addrserver.sin_addr.S_un.S_addr = 0; //����������IP
    addrserver.sin_port = htons(nport);
    if(SOCKET_ERROR == ::bind(m_socklisten,(const struct sockaddr*)&addrserver,sizeof(addrserver))){
        uninitNetWork("bind err\n");
        return false;
    }
    if(SOCKET_ERROR == listen(m_socklisten,128)){
        uninitNetWork("listen err\n");
        return false;
    }
    //�����߳�
    std::thread td(&TCPServer::threadAccept,this);
    td.detach(); //ϵͳ����
    return true;
}

void TCPServer::threadAccept(TCPServer* pthis){
    sockaddr_in  addrclient;
    int nsize= sizeof(addrclient);
    while(1){
        SOCKET sockWaiter = accept(pthis->m_socklisten,(sockaddr *)&addrclient,&nsize);
        printf("client ip:%s \n",inet_ntoa(addrclient.sin_addr));
        //QMutexLocker locker(&client_mutex);
        clients.push_back(sockWaiter);
        //�����߳�
        std::thread td(&TCPServer::threadRecv,pthis,sockWaiter);
        td.detach(); //ϵͳ����
    }
}

void TCPServer::threadRecv(TCPServer* pthis,SOCKET sockWaiter)
{
    while(1){

        if(!pthis->recvData(sockWaiter))
            break;
    }
}
bool TCPServer::recvData(SOCKET sockWaiter)
{
    int nlen;
    //1.���ܰ���С
    int nreadnum = recv(sockWaiter,(char*)&nlen,sizeof(int),0);
    if(nreadnum <=0)
        return false;
    //2.���ܰ�����
    char *pszbuf = new char[nlen];
    int noffset = 0;
    while(nlen){
        nreadnum = recv(sockWaiter,pszbuf+noffset,nlen,0); //8m
        if(nreadnum >0){
            noffset+=nreadnum; //10m
            nlen-=nreadnum; //0m
        }
    }
    tcpKernel::getKernel()->dealData(sockWaiter,pszbuf);

    delete []pszbuf;
    pszbuf=0;
    return true;
}

void TCPServer::uninitNetWork(const char* szerr)
{
    printf(szerr);
    if(m_socklisten){
        closesocket(m_socklisten);
        m_socklisten = 0;
    }
    WSACleanup();
}

bool TCPServer::sendData(SOCKET sockWaiter, char *szbuf, int nlen)
{

    //1.���ͳ���  nlen
    if(send(sockWaiter,(char*)&nlen,sizeof(int),0) <=0)
        return false;
   //2.���Ͱ�����szbuf
    if(send(sockWaiter,szbuf,nlen,0) <=0)
        return false;

    return true;

}

