﻿#ifndef SHOWFILE_H
#define SHOWFILE_H

#include <QWidget>
#include<QTextEdit>
#include"packdef.h"
#include"kernel/IKernel.h"
#include "diff_match_patch.h"
#include<QMessageBox>
#include<QTimer>
#include<QDateTime>
#include<string.h>
#include"md5.h"
namespace Ui {
class showfile;
}

class showfile : public QWidget
{
    Q_OBJECT

public:
    explicit showfile(QWidget *parent = nullptr);
    ~showfile();
public:
    void setkernel(IKernel* pkernel){
        m_pkernel = pkernel;
    }
    std::string FileDigest(QString filename);
    void showfile::timerthread();
public slots:
    void slot_showcontent(FILECONTENT*);
    void slot_modifyfile();
    void slot_showmodify(ModifyFile_RS*);
private slots:
    void on_pushButton_clicked();

private:
    Ui::showfile *ui;
    IKernel* m_pkernel;
    FILECONTENT* m_fc;
    QString f_text;
    long long userId;
    char FileName[MAXSIZE];
    string FileMD5;
    //QTimer* timer;
};

#endif // SHOWFILE_H
