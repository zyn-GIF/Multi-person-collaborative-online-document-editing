﻿#ifndef TCPSERVER_H
#define TCPSERVER_H

#include "INet.h"
#include <stdio.h>
#include <thread>
#include<vector>
#include<QMutex>
class TCPServer:public INet
{
public:
    TCPServer();
    ~TCPServer();
public:
    bool initNetWork(const char* szip = "127.0.0.1",short nport = 8899);
    void uninitNetWork(const char* szerr ="");
    bool sendData(SOCKET sockWaiter,char* szbuf,int nlen);
    bool recvData(SOCKET sockWaiter);
public:
    static void threadAccept(TCPServer* pthis);
    static void threadRecv(TCPServer* pthis,SOCKET sockWaiter);
private:
    SOCKET m_socklisten;
public:
    static std::vector<int> clients;
    static QMutex client_mutex;
};

#endif // TCPSERVER_H
