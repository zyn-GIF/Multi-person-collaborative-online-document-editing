﻿#include <QCoreApplication>
#include"kernel/tcpkernel.h"
int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    Ikernel* pkernel = tcpKernel::getKernel();
    if(pkernel->open()){
        printf("server is running.....\n");
    }



    return a.exec();
}
