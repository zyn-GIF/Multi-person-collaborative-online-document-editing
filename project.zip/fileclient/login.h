﻿#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>
#include"packdef.h"
#include"kernel/IKernel.h"
#include<QMessageBox>
namespace Ui {
class login;
}

class login : public QWidget
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = nullptr);
    ~login();
public:
    void setkernel(IKernel* pkernel)
    {
        m_pkernel = pkernel;
    }

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();
public slots:
    void slot_registerrs(STRU_REGISTER_RS*);

private:
    Ui::login *ui;
    IKernel* m_pkernel;
};

#endif // LOGIN_H
