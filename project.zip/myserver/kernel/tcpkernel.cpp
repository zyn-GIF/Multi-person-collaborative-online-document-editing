﻿#include "tcpkernel.h"

Ikernel* tcpKernel::m_pkernel = new tcpKernel;
tcpKernel::tcpKernel() {
    m_TCPNet = new TCPServer;
    m_Sql = new CMySql;
    strcpy(m_szSystemPath,"D:/BUKA/txwd/File/");
    consumer_thread = new thread(&tcpKernel::deal,this);
}

tcpKernel::~tcpKernel()
{
    delete m_TCPNet;
    delete m_Sql;
}

bool tcpKernel::open()
{
    if(!m_TCPNet->initNetWork())
        return false;
    if(!m_Sql->ConnectMySql("localhost","root","123zyn0507","myfile"))
        return false;
    return true;
}

void tcpKernel::close()
{
    m_TCPNet->uninitNetWork();
}

void tcpKernel::dealData(SOCKET sock, char *szbuf)
{
    switch(*szbuf){
    case _protocol_register_rq:
        registerrq(sock,szbuf);
        break;
    case _protocol_login_rq:
        loginrq(sock,szbuf);
        break;
    case _protocol_getfilelist_rq:
        getfilelist(sock,szbuf);
        break;
    case _protocol_showfile_rq:
        showfile(sock,szbuf);
        break;
    case _protocol_modify_rq://收到修改文件内容的包

        modify(sock,szbuf);
        break;
    case _protocol_modifyuser_rq:
        ModifyUser(sock,szbuf);
        break;
    }



}

void tcpKernel::deal(){

    while(1)
    {
        QQueue<MyOperation> temp;
        //加锁
        QMutexLocker locker(&(this->mutex));
        {
            while(this->op_queue.size()==0){
                //释放锁并等待

                waitcondition.wait(&(this->mutex));
            }
            auto ite=this->op_queue.begin();
            while(ite!=this->op_queue.end()){
                QString path(FilePath);
                char m_md5[45];
                strcpy(m_md5,ite->strMD5);
                // if(0==strcmp(ite->strMD5,FileDigest(path).c_str()))//判断每个操作的md5是否和当前文件相同
                // {//如果相同
                //     temp.enqueue(*ite);//将这个操作加入最新队列（MD5和文件相同）中 并且在原队列清除
                //     ite=op_queue.erase(ite);
                // }
                // else{
                //     ++ite;
                // }
                temp.enqueue(*ite);//将这个操作加入临时队列中 并且在原队列清除
                ite=op_queue.erase(ite);
            }
        }
       //对旧操作进行追更 然后加入临时队列中  临时队列temp中存放的都是与当前文件MD5相同的操作    op_queue是旧队列 temp是版本最新的队列
        while(op_queue.size()>0){
            MyOperation op=op_queue.dequeue();
            this->Updateoperation(op,temp,FileDigest(FilePath));
        }
        //在对真实文件操作的后面加上数据库中日志的写入  追更函数中 如果MD5不同 从数据库中查看
        //一个追更函数 （旧操作队列op_queue，临时队列temp）
        if(temp.size()!=0){
            //处理冲突的操作OT_deal
                QList<MyOperation> Mylist(this->OT_deal(temp));
            //将操作应用到文件
                ModifyFile_RS mrs;
                mrs.num=Mylist.size();
            for(int i=0;i<Mylist.size();++i){

                if(Mylist[i].type==MyInsert){

                    this->insertAtPosition(this->FilePath,Mylist[i].pos,Mylist[i].content);//把操作应用到文件
                    //将操作写入数据库的日志
                    char szsql[SQLLEN]={0};
                    string result_md5=FileDigest(FilePath);
                    int pos=Mylist[i].pos;
                    sprintf(szsql,"insert into operation_log(f_path,base_md5,result_md5,type,operation_content,operation_seq,operation_timestamp,u_id,operation_pos)value('%s','%s','%s','insert','%s','%d',FROM_UNIXTIME(%d),'%d','%d');",FilePath,Mylist[i].strMD5,result_md5.c_str(),Mylist[i].content,i,Mylist[i].timestamp/1000,Mylist[i].userId,pos);
                    m_Sql->UpdateMySql(szsql);
                    //准备将操作广播
                    mrs.modify[i].u_id=Mylist[i].userId;
                    mrs.modify[i].type=MyInsert;
                    mrs.modify[i].pos=Mylist[i].pos;
                    strcpy(mrs.modify[i].content,Mylist[i].content);
                    mrs.modify[i].len=Mylist[i].len;

                }
                else if(Mylist[i].type==MyDelete){
                    this->deleteAtPosition(this->FilePath,Mylist[i].pos,Mylist[i].len);//把操作应用到文件
                    //将操作写入数据库的日志
                    char szsql[SQLLEN]={0};
                    string result_md5=FileDigest(FilePath);
                    int pos=Mylist[i].pos;
                    sprintf(szsql,"insert into operation_log(f_path,base_md5,result_md5,type,operation_content,operation_seq,operation_timestamp,u_id,operation_len,operation_pos)value('%s','%s','%s','delete','NULL','%d','%d','%d','%d',''%d);",FilePath,Mylist[i].strMD5,result_md5.c_str(),i,Mylist[i].timestamp,Mylist[i].userId,Mylist[i].len,pos);
                    m_Sql->UpdateMySql(szsql);
                    //准备将操作广播
                    mrs.modify[i].u_id=Mylist[i].userId;
                    mrs.modify[i].type=MyDelete;
                    mrs.modify[i].pos=Mylist[i].pos;
                    strcpy(mrs.modify[i].content,Mylist[i].content);
                    mrs.modify[i].len=Mylist[i].len;
                }
            }
            //广播发送回复
            std::vector<int> &m_clients=(TCPServer::clients);
            for(auto ite=m_clients.begin();ite!=m_clients.end();++ite){
                m_TCPNet->sendData(*ite,(char*)&mrs,sizeof(mrs));
            }
        }

    }
}

void tcpKernel::Updateoperation(MyOperation&Opx, QQueue<MyOperation> &temp,string filemd5)
{
    //在数据库中查询result_MD5和当前文件MD5相同的操作 判断这个操作的base_md5和需要追更的操作的MD5是不是相同
    //如果不同 递归 只到相同
    filemd5=FileDigest(this->FilePath);
    MyOperation op;
    char szsql[SQLLEN]={0};
    list<string> lststr;
    stack<MyOperation> op_stack;
    while(1)
    {
        sprintf(szsql,"select base_md5,type,operation_content,operation_len from operation_log where result_md5='%s' order by operation_seq;",filemd5.c_str());
        m_Sql->SelectMySql(szsql,4,lststr);
        string base_md5;
        if(lststr.size()>0){//查找到需要加上的操作
            //每改变一个阶段的MD5 会有一系列操作 把他们加入到栈上 直到MD5和这个操作的base_md5相同 把操作出栈通过transformOperation
            while(lststr.size()>0){
                MyOperation t;
                strcpy(t.strMD5,lststr.front().c_str());
                base_md5=t.strMD5;
                lststr.pop_front();
                string type=lststr.front();
                if(type=="insert"){
                    t.type=MyInsert;
                }
                else{
                    t.type=MyDelete;
                }
                lststr.pop_front();
                strcpy(t.content,lststr.front().c_str());
                lststr.pop_front();
                t.len=std::stoll(lststr.front());
                lststr.pop_front();
                op_stack.push(t);
            }
            if(strcmp(Opx.strMD5,base_md5.c_str())==0){
                break;
            }
        }

    }
    while(op_stack.size()>0){
        op=op_stack.top();
        Opx=this->transformOperation(Opx,op);
        op_stack.pop();
    }
    temp.enqueue(Opx);
    return ;
}
MyOperation tcpKernel::transformOperation(//返回可以直接应用在新的MD5的文件上的操作
    const MyOperation& opX,  // 待转换的操作（客户端操作）  //常量引用
    const MyOperation& opY   // 已执行的中间操作（服务器操作）
    ) {
    MyOperation transformedOp = opX;

    if (opX.type == MyInsert && opY.type == MyInsert) {
        // 场景1：INSERT vs INSERT
        if (opY.pos <= opX.pos) {
            transformedOp.pos += opY.len;
        }
    } else if (opX.type == MyInsert && opY.type == MyDelete) {
        // 场景2：INSERT vs DELETE
        int yEnd = opY.pos + opY.len;
        if (opY.pos <= opX.pos && opX.pos < yEnd) {
            transformedOp.pos = opY.pos;
        } else if (opX.pos >= yEnd) {
            transformedOp.pos -= opY.len;
        }
    } else if (opX.type == MyDelete && opY.type == MyInsert) {
        // 场景3：DELETE vs INSERT
        if (opY.pos <= opX.pos) {
            transformedOp.pos += opY.len;
        }
        if (opY.pos <= opX.pos + opX.len) {
            transformedOp.len += opY.len;
        }
    } else if (opX.type == MyDelete && opY.type == MyDelete) {
        // 场景4：DELETE vs DELETE
        int xStart = opX.pos;
        int xEnd = opX.pos + opX.len;
        int yStart = opY.pos;
        int yEnd = opY.pos + opY.len;

        if (yEnd <= xStart) {
            // OpY在OpX之前：OpX整体前移
            transformedOp.pos -= opY.len;
            transformedOp.len -= opY.len;
        } else if (yStart >= xEnd) {
            // OpY在OpX之后：OpX终点前移
            transformedOp.len -= opY.len;
        } else {
            // 重叠：计算重叠长度，OpX终点减少重叠部分
            int overlapStart = qMax(xStart, yStart);
            int overlapEnd = qMin(xEnd, yEnd);
            int overlapLen = overlapEnd - overlapStart;
            transformedOp.len -= overlapLen;
        }
    }

    return transformedOp;
}
void tcpKernel::modify(SOCKET sock, char *szbuf)
{
    ModifyFile_RQ* mr = (ModifyFile_RQ*)szbuf;

    for(int i=0;i<mr->num;i++)
    {
        if(mr->modify[i].type!=MyEqual){
            MyOperation u_op;
            u_op.userId=mr->u_id;
            u_op.type=mr->modify[i].type;
            strcpy(u_op.content,mr->modify[i].content);
            u_op.pos=mr->modify[i].pos;
            u_op.len=mr->modify[i].len;
            u_op.timestamp=mr->modify[i].timestamp;
            strcpy(u_op.strMD5,mr->modify[i].strMD5);
            //加锁
            QMutexLocker locker(&mutex);
            op_queue.enqueue(u_op);
            Sleep(1);
            waitcondition.wakeOne();
            //解锁
        }
    }


}
void tcpKernel::registerrq(SOCKET sock, char *szbuf)
{
    STRU_REGISTER_RQ* psrr = (STRU_REGISTER_RQ*)szbuf;
    STRU_REGISTER_RS srr;
    srr.m_szResult = _register_err;
    char szsql[SQLLEN]={0};
    list<string> lststr;

    sprintf(szsql,"insert into user(u_name,u_tel,u_password) value('%s','%lld','%s');",psrr->m_szUser,psrr->m_tel,psrr->m_szPassword);
    if(m_Sql->UpdateMySql(szsql)){
        srr.m_szResult = _register_success;
        sprintf(szsql,"select u_id from user where u_name = '%s';",psrr->m_szUser);
        m_Sql->SelectMySql(szsql,1,lststr);
        if(lststr.size()>0){
            string strUser = lststr.front();
            lststr.pop_front();
            char szPath[MAX_PATH];
            sprintf(szPath,"%s%s",m_szSystemPath,strUser.c_str());
            CreateDirectoryA(szPath,0);
        }
    }
    m_TCPNet->sendData(sock,(char*)&srr,sizeof(srr));
}

void tcpKernel::loginrq(SOCKET sock, char *szbuf)
{
    STRU_LOGIN_RQ* pslr = (STRU_LOGIN_RQ*)szbuf;
    STRU_LOGIN_RS slr;
    char szsql[SQLLEN]={0};
    list<string> lststr;
    slr.m_szResult = _login_usernoexist;
    sprintf(szsql,"select u_password,u_id from user where u_name = '%s';",pslr->m_szUser);
    m_Sql->SelectMySql(szsql,2,lststr);
    if(lststr.size()>0)
    {
        slr.m_szResult = _login_passwd_err;
        string UserPasswd = lststr.front();
        lststr.pop_front();
        if(0==strcmp(UserPasswd.c_str(),pslr->m_szPassword)){
            slr.m_szResult = _login_success;
            string UserId = lststr.front();
            lststr.pop_front();
            slr.m_userId = atoll(UserId.c_str());
        }


    }

    m_TCPNet->sendData(sock,(char*)&slr,sizeof(slr));
}

void tcpKernel::getfilelist(SOCKET sock, char *szbuf)
{

        STRU_GETFIIELIST_RQ* psgr = (STRU_GETFIIELIST_RQ*)szbuf;
        STRU_GETFIIELIST_RS sgr;
        char szsql[SQLLEN]={0};
        list<string> lststr;
        int i=0;

        sprintf(szsql,"select f_name,f_uploadtime,f_ower,f_permission,f_id from myview where u_id=%lld;",psgr->m_userId);
        m_Sql->SelectMySql(szsql,5,lststr);
        while(lststr.size()>0)
        {
            string strFileName = lststr.front();
            lststr.pop_front();
            string strUploadtime = lststr.front();
            lststr.pop_front();
            string strOwner = lststr.front();
            lststr.pop_front();
            string strPermission = lststr.front();
            lststr.pop_front();
            string strF_id = lststr.front();
            lststr.pop_front();
            strcpy(sgr.m_aryFileInfo[i].m_szFileName,strFileName.c_str());
            strcpy(sgr.m_aryFileInfo[i].m_szFileUploadTime,strUploadtime.c_str());
            strcpy(sgr.m_aryFileInfo[i].m_szFileOwner,strOwner.c_str());
            strcpy(sgr.m_aryFileInfo[i].m_FilePermission,strPermission.c_str());
            sgr.m_aryFileInfo[i].f_id = atoll(strF_id.c_str());
            i++;
            if(i==FILENUM || lststr.size()==0)
            {
                sgr.m_fileNum=i;
                m_TCPNet->sendData(sock,(char*)&sgr,sizeof(sgr));
                i=0;
                ZeroMemory(sgr.m_aryFileInfo,sizeof(sgr.m_aryFileInfo));
            }
        }

}

void tcpKernel::showfile(SOCKET sock, char *szbuf)
{
    STRU_SHOWFILE_RQ* pssr = (STRU_SHOWFILE_RQ*)szbuf;
    STRU_SHOWFILE_RS ssr;
    char szsql[SQLLEN]={0};
    list<string> lststr;

    sprintf(szsql,"select f_path,f_name,f_permission from myview where u_id = %lld;",pssr->f_id);
    m_Sql->SelectMySql(szsql,3,lststr);
    if(lststr.size()>0)
    {
        string szFilePath = lststr.front();
        strcpy(FilePath,szFilePath.c_str());
        lststr.pop_front();
        string szFileName = lststr.front();
        lststr.pop_front();
        string szFilepermission = lststr.front();
        lststr.pop_front();
        strcpy(ssr.m_FilePath,szFilePath.c_str());
        strcpy(ssr.m_szFileName,szFileName.c_str());
        strcpy(ssr.m_FilePermission,szFilepermission.c_str());
        m_TCPNet->sendData(sock,(char*)&ssr,sizeof(ssr));
    }
}
void tcpKernel::insertAtPosition(string filename, size_t pos, const std::string& data) {
    // 1. 读取插入点后的内容
    std::fstream file(filename, std::ios::in | std::ios::out|std::ios::binary);
    file.seekg(pos);
    std::string remainingContent(
        (std::istreambuf_iterator<char>(file)),
        std::istreambuf_iterator<char>()
        );

    // 2. 回到插入点，写入新数据
    file.seekp(pos);
    file << data;

    // 3. 追加之前的内容
    file << remainingContent;
    file.close();
}
void tcpKernel::deleteAtPosition(string filename, size_t pos, size_t length) {
    // 1. 打开文件读取全部内容
    std::ifstream inFile(filename, std::ios::binary);


    // 读取文件内容
    std::string content(
        (std::istreambuf_iterator<char>(inFile)),
        std::istreambuf_iterator<char>()
        );
    inFile.close();

    // 2. 删除指定位置的数据
    if (pos >= content.size()) {
        throw std::out_of_range("删除位置超出文件范围");
    }
    content.erase(pos, length);

    // 3. 将修改后的内容写回文件
    std::ofstream outFile(filename, std::ios::binary | std::ios::trunc);

    outFile << content;
    outFile.close();
}

void tcpKernel::ModifyUser(SOCKET sock,char* szbuf)
{
    Modify_User_RQ* pmur = (Modify_User_RQ*)szbuf;
    Modify_User_RS mur;
    char szsql[SQLLEN]={0};
    list<string> lststr;


    mur.u_id=pmur->u_id;
    sprintf(szsql,"select u_name from user where u_id=%lld;",mur.u_id);
    m_Sql->SelectMySql(szsql,1,lststr);
    char pname[MAXSIZE]={0};
    if(lststr.size()>0)
    {
        string szName = lststr.front();
        lststr.pop_front();
        strcpy(pname,szName.c_str());
    }
    //将用户插入到表中
    sprintf(szsql,"insert into file_permission(f_name,u_name,f_permission) value('%s','%s','%s');",pmur->m_szFileName,pname,pmur->m_FilePermission);
    m_Sql->UpdateMySql(szsql);

    while(1){
    //查询这个文件正在编辑的所有用户
        sprintf(szsql,"SELECT u_name FROM myfile.file_permission where f_name = '%s';",pmur->m_szFileName);
        m_Sql->SelectMySql(szsql,1,lststr);
        if(lststr.size()>0){
        list<string> list;
            if(list!=lststr){
            list=lststr;
            }else{
                continue;
            }

            mur.num=lststr.size();
            for(int i=0;i<mur.num;i++){
                string szUserName=lststr.front();
                lststr.pop_front();
                strcpy(mur.user[i].u_name,szUserName.c_str());
            }
        }


        m_TCPNet->sendData(sock,(char*)&mur,sizeof(mur));
    }

}

QList<MyOperation> tcpKernel::OT_deal(QQueue<MyOperation>&queue)
{
    QList<MyOperation> list_timestamp(this->sortQueueByTimestamp(queue));
    for (int i = 0; i < list_timestamp.size(); ++i) {
        const MyOperation& prevOp = list_timestamp[i];  // 当前前置操作
        // 调整所有i之后的后置操作
        for (int j = i + 1; j < list_timestamp.size(); ++j) {
            MyOperation& currOp = list_timestamp[j];    // 当前需要适配的后置操作

            if (prevOp.type == MyInsert) {
                // 前置是插入：后置位置 ≥ 插入位置 → 位置 += 插入长度
                if (currOp.pos >= prevOp.pos) {
                    currOp.pos += prevOp.len;
                    qDebug() << "操作" << j << "因前置插入，位置从" << (currOp.pos - prevOp.len)
                             << "调整为" << currOp.pos;
                }
            } else if (prevOp.type == MyDelete) {
                // 前置是删除：后置位置 ≥ 删除位置 → 位置 -= 删除长度
                if (currOp.pos >= prevOp.pos) {
                    currOp.pos -= prevOp.len;
                    // 边界保护：位置不能小于0
                    if (currOp.pos < 0) currOp.pos = 0;
                    qDebug() << "操作" << j << "因前置删除，位置从" << (currOp.pos + prevOp.len)
                             << "调整为" << currOp.pos;
                }
            }
        }
    }

    // QQueue<Operation> sortedQueue;
    // for (const Operation& op : list_timestamp) {
    //     sortedQueue.enqueue(op);
    // }

    // return sortedQueue;
    return list_timestamp;
}
QList<MyOperation> tcpKernel::sortQueueByTimestamp(QQueue<MyOperation>& queue) {
    // 步骤1：将QQueue转换为QList（QList支持随机访问，可排序）

    QList<MyOperation> opList;
    while (!queue.isEmpty()) {
        // 从队列头部取出元素，加入列表（原队列会逐步清空）
        opList.append(queue.dequeue());
    }
    // 步骤2：按时间戳升序排序（时间戳小的在前）
    std::sort(opList.begin(), opList.end(),
              [](const MyOperation& a, const MyOperation& b) {
                  // 优先按时间戳排序
                  if (a.timestamp != b.timestamp) {
                      return a.timestamp < b.timestamp;
                  }
                  // 时间戳相同则按位置排序（确保排序稳定性）
                  return a.pos < b.pos;
              });

    return opList;

}

string tcpKernel::FileDigest(QString filename) {

    QFile file(filename);

    file.open(QIODevice::ReadOnly);
    if (!file.isOpen())
        return "";

    MD5 md5;
    char buffer[1024];
    while (1)
    {
        qint64 length =  file.read(buffer, 1024);

        if (length > 0)
            md5.update(buffer, length);
        else
            break;
    }
    file.close();
    return md5.toString();
}
