﻿#ifndef TCPKERNEL_H
#define TCPKERNEL_H

#include <QObject>
#include"IKernel.h"
#include"../client/INet.h"
#include"packdef.h"
class tcpkernel : public QObject,public IKernel
{
    Q_OBJECT
public:
    explicit tcpkernel(QObject *parent = nullptr);
    ~tcpkernel();
public:
    bool connectServer(const char* szip = "127.0.0.1",short nport=8899);
    void disconnectServer(const char* szerr="");
    bool sendData(const char* szbuf,int nlen);
    bool dealData(const char* szbuf);

private:
    INet* m_pNet;
signals:
    void signal_registerrs(STRU_REGISTER_RS*);
    void signal_loginrs(STRU_LOGIN_RS*);
    void signal_getfilelistrs(STRU_GETFIIELIST_RS*);
    void signal_showfilers(STRU_SHOWFILE_RS*);
    void signal_showmodify(ModifyFile_RS*);
};

#endif // TCPKERNEL_H
