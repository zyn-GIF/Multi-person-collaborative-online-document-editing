#include "tcpclient.h"

TCPClient::TCPClient(IKernel* p)
{
    m_sockclient =0;
    m_pKernel = p;
}

TCPClient::~TCPClient()
{

}

bool TCPClient::initNetWork(const char *szip, short nport)
{
    WORD wVersionRequested;
    WSADATA wsaData;
    int err;

    /* Use the MAKEWORD(lowbyte, highbyte) macro declared in Windef.h */
    wVersionRequested = MAKEWORD(2, 2);

    err = WSAStartup(wVersionRequested, &wsaData);
    if (err != 0) {
        /* Tell the user that we could not find a usable */
        /* Winsock DLL.                                  */
        printf("WSAStartup failed with error: %d\n", err);
        return false;
    }

    if (LOBYTE(wsaData.wVersion) != 2 || HIBYTE(wsaData.wVersion) != 2) {
        /* Tell the user that we could not find a usable */
        /* WinSock DLL.                                  */
        uninitNetWork("Could not find a usable version of Winsock.dll\n");
        return false;
    }
    else
        printf("The Winsock 2.2 dll was found okay\n");

    m_sockclient = socket(AF_INET,SOCK_STREAM,0);
    if(m_sockclient == INVALID_SOCKET){
        uninitNetWork("socket err\n");
        return false;
    }
    sockaddr_in  addrserver;
    addrserver.sin_family = AF_INET;
    addrserver.sin_addr.S_un.S_addr = inet_addr(szip); //����������IP
    addrserver.sin_port = htons(nport);
    if( SOCKET_ERROR ==connect(m_sockclient,(const struct sockaddr*)&addrserver,sizeof(addrserver))){
        uninitNetWork("connect err\n");
        return false;
    }
    //�����߳�----��������
    std::thread td(&TCPClient::threadRecv,this);
    td.detach();
    return true;
}

void TCPClient::threadRecv(TCPClient *pthis)
{
    while(1){
        pthis->recvData();
    }
}

bool TCPClient::recvData()
{
    int nlen;
    //1.���ܰ���С
    int nreadnum = recv(m_sockclient,(char*)&nlen,sizeof(int),0);
    if(nreadnum <=0)
        return false;
    //2.���ܰ�����
    char *pszbuf = new char[nlen];
    int noffset = 0;
    while(nlen){
        nreadnum = recv(m_sockclient,pszbuf+noffset,nlen,0); //8m
        if(nreadnum >0){
            noffset+=nreadnum; //10m
            nlen-=nreadnum; //0m
        }
    }
    //todo

    m_pKernel->dealData(pszbuf);

    delete []pszbuf;
    pszbuf= 0;
    return true;
}


void TCPClient::uninitNetWork(const char *szerr)
{
    printf(szerr);
    if(m_sockclient){
        closesocket(m_sockclient);
        m_sockclient=0;
    }
    WSACleanup();

}

bool TCPClient::sendData(const char *szbuf, int nlen)
{

    //1.���ͳ���  nlen
    if(send(m_sockclient,(char*)&nlen,sizeof(int),0) <=0)
        return false;
    //2.���Ͱ�����szbuf
    if(send(m_sockclient,szbuf,nlen,0) <=0)
        return false;

    return true;
}



