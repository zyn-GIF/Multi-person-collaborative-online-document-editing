﻿#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include"kernel/tcpkernel.h"
#include"login.h"
#include<QTableWidgetItem>
#include<thread>
#include<QFile>
#include<QTextEdit>
#include<QDialog>
#include<Windows.h>
#include"showfile.h"
QT_BEGIN_NAMESPACE
namespace Ui {
class Widget;
}
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
public slots:
    void slot_loginrs(STRU_LOGIN_RS*);
    void slot_getfilelistrs(STRU_GETFIIELIST_RS*);
    void slot_showfilerq(QTableWidgetItem* item);
    void slot_showfilers(STRU_SHOWFILE_RS*);
    //void slot_showcontent(QString content);

   // void readfile(STRU_SHOWFILE_RS *pssr);
signals:
    void signal_finishread(FILECONTENT*);
public:
    long long m_puserId;
    long m_FileNum;
private:
    Ui::Widget *ui;
    IKernel* m_pkernel;
    login* m_plogin;
    HANDLE m_Semaphore;
    showfile* m_pshowfile;
    FILECONTENT fc;
};
#endif // WIDGET_H
