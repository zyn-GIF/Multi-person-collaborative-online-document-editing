﻿#include "login.h"
#include "ui_login.h"

login::login(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::login)
{
    ui->setupUi(this);
}

login::~login()
{
    delete ui;
}

void login::on_pushButton_clicked()//注册
{
    QString u_name = ui->lineEdit_regist_UserName->text();
    QString u_tel = ui->lineEdit_registe_tel->text();
    QString u_passwd = ui->lineEdit_registe_passwd->text();
    STRU_REGISTER_RQ srr;
    strcpy(srr.m_szUser,u_name.toStdString().c_str());
    srr.m_tel = atoll(u_tel.toStdString().c_str());
    strcpy(srr.m_szPassword,u_passwd.toStdString().c_str());

    m_pkernel->sendData((char*)&srr,sizeof(srr));
}


void login::on_pushButton_2_clicked()//登录
{
    QString u_name = ui->lineEdit_login_UserName->text();
    QString u_passwd = ui->lineEdit_login_passwd->text();
    STRU_LOGIN_RQ slr;
    strcpy(slr.m_szUser,u_name.toStdString().c_str());
    strcpy(slr.m_szPassword,u_passwd.toStdString().c_str());

    m_pkernel->sendData((char*)&slr,sizeof(slr));
}

void login::slot_registerrs(STRU_REGISTER_RS *srr)
{
    const char* szResult=NULL;
    if(srr->m_szResult==_register_success){
        szResult = "regist success";
    }
    QMessageBox::information(this,"title",szResult);

}



