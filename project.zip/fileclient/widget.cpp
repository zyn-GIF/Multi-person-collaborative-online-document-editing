﻿#include "widget.h"
#include "ui_widget.h"
#include<QDebug>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    m_pkernel = new tcpkernel;
    if(m_pkernel->connectServer()){
        qDebug()<<"connect success";
    }else
        qDebug()<<"connect err";
    m_plogin = new login;
    m_plogin->setkernel(m_pkernel);
    m_plogin->show();

    m_pshowfile = new showfile;
    m_pshowfile->setkernel(m_pkernel);


    connect((tcpkernel*)m_pkernel,&tcpkernel::signal_registerrs,m_plogin,&login::slot_registerrs,Qt::BlockingQueuedConnection);
    connect((tcpkernel*)m_pkernel,&tcpkernel::signal_loginrs,this,&Widget::slot_loginrs,Qt::BlockingQueuedConnection);
    connect((tcpkernel*)m_pkernel,&tcpkernel::signal_getfilelistrs,this,&Widget::slot_getfilelistrs,Qt::BlockingQueuedConnection);
    connect(ui->tableWidget,&QTableWidget::itemClicked,this,&Widget::slot_showfilerq,Qt::QueuedConnection);
    connect((tcpkernel*)m_pkernel,&tcpkernel::signal_showfilers,this,&Widget::slot_showfilers,Qt::BlockingQueuedConnection);
   // connect(this,&Widget::signal_finishread,m_pshowfile,&showfile::slot_showcontent,Qt::BlockingQueuedConnection);
    connect(this,&Widget::signal_finishread,m_pshowfile,&showfile::slot_showcontent,Qt::QueuedConnection);
    connect((tcpkernel*)m_pkernel,&tcpkernel::signal_showmodify,m_pshowfile,&showfile::slot_showmodify,Qt::BlockingQueuedConnection);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::slot_loginrs(STRU_LOGIN_RS *pslr)
{
    const char* szResult = NULL;
    if(pslr->m_szResult ==_login_usernoexist)
    {
        szResult = "_login_usernoexist";
    }
    else if(pslr->m_szResult==_login_passwd_err)
    {
        szResult = "_login_passwd_err";
    }
    else{
        //szResult = "_login_success";
        m_plogin->hide();
        this->show();
        //记录UserId
        m_puserId = pslr->m_userId;
        //获取文件列表
        STRU_GETFIIELIST_RQ sgr;
        sgr.m_userId = m_puserId;
        m_pkernel->sendData((char*)&sgr,sizeof(sgr));
        return ;
    }
    QMessageBox::information(this,"title",szResult);
}

void Widget::slot_getfilelistrs(STRU_GETFIIELIST_RS *sgr)
{
    m_FileNum = sgr->m_fileNum;
    for(int i=0;i<m_FileNum;i++)
    {
        QTableWidgetItem* pitem = new QTableWidgetItem(sgr->m_aryFileInfo[i].m_szFileName);
        ui->tableWidget->setItem(i,0,pitem);

        pitem = new QTableWidgetItem(sgr->m_aryFileInfo[i].m_szFileUploadTime);
        ui->tableWidget->setItem(i,1,pitem);

        pitem = new QTableWidgetItem(sgr->m_aryFileInfo[i].m_szFileOwner);
        ui->tableWidget->setItem(i,2,pitem);

        pitem = new QTableWidgetItem(sgr->m_aryFileInfo[i].m_FilePermission);
        ui->tableWidget->setItem(i,3,pitem);
        //设置隐藏数据字段 文件ID
        QTableWidgetItem* HideItem = ui->tableWidget->item(i, 0);
        if (HideItem) {
            HideItem->setData(Qt::UserRole, sgr->m_aryFileInfo[i].f_id);
        }

    }


}

void Widget::slot_showfilerq(QTableWidgetItem *item)
{

    int row = item->row();
    int column = item->column();
    STRU_SHOWFILE_RQ ssr;

    QTableWidgetItem* pitem = ui->tableWidget->item(row, column);
    ssr.f_id = pitem->data(Qt::UserRole).toLongLong();

    m_pkernel->sendData((char*)&ssr,sizeof(ssr));
}

void Widget::slot_showfilers(STRU_SHOWFILE_RS *pssr)
{
    //当用户点击文件所在行 发送信号 调用槽函数slot_showfilers 槽函数中创建线程读取文件内容 这时槽函数阻塞 等到线程函数读取结束 将content发送给槽函数 槽函数将content

    QString strPath = pssr->m_FilePath;
    //std::thread td(&Widget::readfile,this,pssr);
    QFile file(strPath);
    if(!file.open(QIODevice::ReadOnly))
    {
        return ;
    }
    QTextStream in(&file);
    in.setCodec("UTF-8");
    QString content = in.readAll();
    file.close();

    //FILECONTENT fc;

    strcpy(fc.content,content.toStdString().c_str());
    fc.m_userId = m_puserId;
    strcpy(fc.m_szFileName,pssr->m_szFileName);
    strcpy(fc.m_FilePermission,pssr->m_FilePermission);
    strcpy(fc.m_FilePath,pssr->m_FilePath);
    emit signal_finishread(&fc);


}

// void Widget::slot_showcontent(QString content)
// {
//     // QDialog* dialog = new QDialog(this);
//     // dialog->setWindowTitle("文件内容");

//     // dialog->show();
//     m_pshowfile.setWindowTitle(QString::fromUtf8("文件内容"));
//     QTextEdit* textedit = new QTextEdit(m_pshowfile);
//     textedit->setGeometry(30, 30, 380, 128);
//     textedit->setPlainText(content);
//     m_pshowfile.show();

//     //发信号 让slot_showfilers继续执行
// //ReleaseSemaphore(m_Semaphore,1,0);
// }


// void Widget::readfile(STRU_SHOWFILE_RS *pssr)
// {
//     QString path = pssr->m_FilePath;

//     QFile file(path);
//     if(!file.open(QIODevice::ReadOnly))
//     {
//         return ;
//     }
//     QTextStream in(&file);
//     in.setCodec("UTF-8");
//     QString content = in.readAll();
//     file.close();
//     // std::list<std::string> lststr;
//     // lststr.push_front(pssr->m_szFileName);
//     // lststr.push_back(content.toStdString());

//    emit signal_finishread(content);


// }


