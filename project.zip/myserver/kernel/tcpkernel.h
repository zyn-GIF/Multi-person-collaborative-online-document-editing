﻿#ifndef TCPKERNEL_H
#define TCPKERNEL_H

#include "IKernel.h"
#include"../server/tcpserver.h"
#include"../mysql/CMySql.h"
#include"packdef.h"
#include<fstream>
#include<QQueue>
#include<QFile>
#include<QList>
#include<algorithm>
#include<QDebug>
#include<QMutex>
#include<QWaitCondition>
#include"md5.h"
#include<stack>
class tcpKernel : public Ikernel
{
private:
    tcpKernel();
    ~tcpKernel();
public:
    virtual bool open();
    virtual void close();
    virtual void dealData(SOCKET sock,char* szbuf);
    static Ikernel* getKernel(){
        return m_pkernel;
    }
    void deal();
public:
    void registerrq(SOCKET sock,char* szbuf);
    void loginrq(SOCKET sock,char* szbuf);
    void getfilelist(SOCKET sock,char* szbuf);
    void showfile(SOCKET sock,char* szbuf);
    void modify(SOCKET sock,char* szbuf);
    void insertAtPosition(string filename, size_t pos, const std::string& data);
    void deleteAtPosition(string filename, size_t pos, size_t length);
    void ModifyUser(SOCKET sock,char* szbuf);
    string FileDigest(QString filename);
    QList<MyOperation> OT_deal(QQueue<MyOperation>&);
    QList<MyOperation> sortQueueByTimestamp(QQueue<MyOperation>& queue);
    void Updateoperation(MyOperation&Opx,QQueue<MyOperation>&temp,string filemd5);
    MyOperation transformOperation(const MyOperation& opX,const MyOperation& opY);
private:
    INet* m_TCPNet;
    CMySql* m_Sql;
    static Ikernel* m_pkernel;
    char m_szSystemPath[MAX_PATH];//目录路径
    char FilePath[MAX_PATH];//文件路径
    QQueue<MyOperation> op_queue;
    QMutex mutex;
    QWaitCondition waitcondition;
    thread* consumer_thread;

};

#endif // TCPKERNEL_H
