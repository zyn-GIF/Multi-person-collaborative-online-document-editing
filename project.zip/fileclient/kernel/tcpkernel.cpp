﻿#include "tcpkernel.h"
#include"../client/tcpclient.h"
tcpkernel::tcpkernel(QObject *parent)
    : QObject{parent}
{
    m_pNet = new TCPClient(this);
}

tcpkernel::~tcpkernel()
{
    delete m_pNet;

}

bool tcpkernel::connectServer(const char *szip, short nport)
{
    if(!m_pNet->initNetWork(szip,nport))
        return false;
    return true;
}

void tcpkernel::disconnectServer(const char *szerr)
{
    m_pNet->uninitNetWork(szerr);
}

bool tcpkernel::sendData(const char *szbuf, int nlen)
{
    if(!m_pNet->sendData(szbuf,nlen))
        return false;
    return true;

}

bool tcpkernel::dealData(const char *szbuf)
{
    switch (*szbuf) {
    case _protocol_register_rs:
        emit signal_registerrs((STRU_REGISTER_RS*)szbuf);
    break;
    case _protocol_login_rs:
        emit signal_loginrs((STRU_LOGIN_RS*)szbuf);
    break;
    case _protocol_getfilelist_rs:
        emit signal_getfilelistrs((STRU_GETFIIELIST_RS*)szbuf);
    break;
    case _protocol_showfile_rs:
        emit signal_showfilers((STRU_SHOWFILE_RS*)szbuf);
        break;
    case _protocol_modify_rs:
        emit signal_showmodify((ModifyFile_RS*)szbuf);
        break;

    }
    return true;
}
