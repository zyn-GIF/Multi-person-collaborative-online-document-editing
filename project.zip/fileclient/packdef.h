﻿#include<QDateTime>
#ifndef PACKDEF_H
#define PACKDEF_H

#define _protocol_base  1

//用户登录
#define _protocol_login_rq  _protocol_base+1
#define _protocol_login_rs  _protocol_base+2
//注册账号
#define _protocol_register_rq  _protocol_base+3
#define _protocol_register_rs  _protocol_base+4
//获取文件列表
#define _protocol_getfilelist_rq       _protocol_base+5
#define _protocol_getfilelist_rs       _protocol_base+6
//显示文件
#define _protocol_showfile_rq       _protocol_base+7
#define _protocol_showfile_rs       _protocol_base+8
//修改文件内容
#define _protocol_modify_rq       _protocol_base+9
#define _protocol_modify_rs       _protocol_base+10
//修改文件用户
#define _protocol_modifyuser_rq       _protocol_base+11
#define _protocol_modifyuser_rs       _protocol_base+12


#define MAXSIZE   45
#define FILENUM    20
#define SQLLEN    300
#define ONEPAGE  4096
#define MDFNUM 20
//协议包
struct STRU_BASE{
    char m_ntype;
};

#define _register_err    0
#define _register_success  1

#define _login_usernoexist 0
#define _login_passwd_err  1
#define _login_success     2

#define MyEqual 0
#define MyInsert 1
#define MyDelete 2

//申请账号
struct STRU_REGISTER_RQ:public STRU_BASE{
    STRU_REGISTER_RQ(){
        m_ntype = _protocol_register_rq;
    }
    long long m_tel;
    char m_szUser[MAXSIZE];
    char m_szPassword[MAXSIZE];
};
struct STRU_REGISTER_RS:public STRU_BASE{
    STRU_REGISTER_RS(){
        m_ntype = _protocol_register_rs;
    }

    char m_szResult;
};
//登录
struct STRU_LOGIN_RQ:public STRU_BASE{
    STRU_LOGIN_RQ(){
        m_ntype = _protocol_login_rq;
    }
    char m_szUser[MAXSIZE];
    char m_szPassword[MAXSIZE];
};
struct STRU_LOGIN_RS:public STRU_BASE{
    STRU_LOGIN_RS(){
        m_ntype = _protocol_login_rs;
    }
    long long m_userId;
    char m_szResult;
};

//获取文件列表
struct STRU_GETFIIELIST_RQ:public STRU_BASE{
    STRU_GETFIIELIST_RQ(){
        m_ntype = _protocol_getfilelist_rq;
    }
    long long m_userId;
};
struct FILECONTENT{
    char m_szFileName[MAXSIZE];
    char content[MAXSIZE];
    long long m_userId;
    char m_FilePermission[MAXSIZE];
    char m_FilePath[MAXSIZE];
};
struct FILEINFO{
    char m_szFileName[MAXSIZE];
    char m_szFileUploadTime[MAXSIZE];
    char m_szFileOwner[MAXSIZE];
    char m_FilePermission[MAXSIZE];
    long long f_id;
};
struct STRU_GETFIIELIST_RS:public STRU_BASE{
    STRU_GETFIIELIST_RS(){
        m_ntype = _protocol_getfilelist_rs;
    }
    FILEINFO m_aryFileInfo[FILENUM];
    int m_fileNum;
};

struct STRU_SHOWFILE_RQ:public STRU_BASE{
    STRU_SHOWFILE_RQ(){
        m_ntype = _protocol_showfile_rq;
    }

    long long f_id;
};
struct STRU_SHOWFILE_RS:public STRU_BASE{
    STRU_SHOWFILE_RS(){
        m_ntype = _protocol_showfile_rs;
    }
    char m_FilePath[MAXSIZE];
    char m_szFileName[MAXSIZE];
    char m_FilePermission[MAXSIZE];
};
//用于服务器的冲突检测和转换的数据结构
struct MyOperation{
    int type;//操作类型
    int pos;//操作位置
    char content[MAXSIZE];//操作内容
    long long len;//操作所覆盖的长度
    qint64 timestamp;//操作时间
    long long userId;//操作的用户ID
    char strMD5[MAXSIZE];//所修改文件的MD5值
};

//修改文件内容
struct Modify{
    int pos;
    int type;
    char content[MAXSIZE];
    long long len;
    qint64 timestamp;
    char strMD5[45];
};
struct Modify_rs{
    int pos;
    int type;
    char content[MAXSIZE];
    long long len;
    long long u_id;
};
//修改文件内容包
struct ModifyFile_RQ:public STRU_BASE{
    ModifyFile_RQ(){
        m_ntype = _protocol_modify_rq;
    }
    int num;
    long long u_id;
    char m_szFileName[MAXSIZE];
    Modify modify[MDFNUM]{};
};
//修改文件内容的回复包 将修改内容广播应用在所有正在编辑的客户端
struct ModifyFile_RS:public STRU_BASE{
    ModifyFile_RS(){
        m_ntype = _protocol_modify_rs;
    }
    int num;
    Modify_rs modify[MDFNUM]{};
};
//编辑文件的用户
struct Modify_User_RQ:public STRU_BASE{
    Modify_User_RQ(){
        m_ntype = _protocol_modifyuser_rq;
    }
    long long u_id;
    char m_szFileName[MAXSIZE];
    char m_FilePermission[MAXSIZE];
};
struct ModifyUser{
    char u_name[MAXSIZE];
};

struct Modify_User_RS:public STRU_BASE{
    Modify_User_RS(){
        m_ntype = _protocol_modifyuser_rs;
    }
    bool result;
    long long u_id;
    ModifyUser user[MAXSIZE]{};
    int num;
};
#endif // PACKDEF_H
