﻿#ifndef TCPCLIENT_H
#define TCPCLIENT_H

#include <winsock2.h>
#include <stdio.h>
#include <thread>
#include"INet.h"
#include"kernel/IKernel.h"
class TCPClient:public INet
{
public:
    TCPClient(IKernel* p);
    ~TCPClient();
public:
    bool initNetWork(const char* szip = "127.0.0.1",short nport=8899);
    void uninitNetWork(const char* szerr="");
    bool sendData(const char* szbuf,int nlen);
    bool recvData();
    static void threadRecv(TCPClient *);
private:
    SOCKET m_sockclient;
    IKernel* m_pKernel;
};

#endif // TCPCLIENT_H
